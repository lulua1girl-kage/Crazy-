package com.crazyalarm.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.*

class WakeService : Service() {
    companion object { const val ACTION_DUCK = "com.crazyalarm.app.DUCK" }
    private var mp: MediaPlayer? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_DUCK) {
            mp?.setVolume(0.12f, 0.12f)
            if (mp == null) stopSelf()
            return START_NOT_STICKY
        }
        val strict = i?.getBooleanExtra("strict", false) == true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("wake", "Wake session", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) })
        val open = PendingIntent.getActivity(this, 7,
            Intent(this, WakeActivity::class.java).putExtra("strict", strict)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "wake").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Crazy Alarm").setContentText("Tap to confirm you're up")
            .setCategory(Notification.CATEGORY_ALARM).setOngoing(true)
            .setContentIntent(open).setFullScreenIntent(open, true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(7, n)
        if (mp == null) startSound()
        return START_NOT_STICKY
    }

    private fun startSound() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            mp = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                setDataSource(this@WakeService, uri); isLooping = true; prepare(); start()
            }
        } catch (_: Exception) {}
        getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 400), 0))
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() {
        mp?.release(); mp = null
        getSystemService(Vibrator::class.java).cancel()
        super.onDestroy()
    }
}
