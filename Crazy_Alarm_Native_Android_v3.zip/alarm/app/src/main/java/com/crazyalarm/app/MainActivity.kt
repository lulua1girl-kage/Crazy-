package com.crazyalarm.app

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.widget.*
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {
    private lateinit var picker: TimePicker
    private lateinit var repeat: Switch
    private lateinit var strict: Switch
    private lateinit var info: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_main)
        picker = findViewById(R.id.timePicker); picker.setIs24HourView(true)
        repeat = findViewById(R.id.repeat); strict = findViewById(R.id.strict); info = findViewById(R.id.info)
        val cfg = AlarmStore.load(this)
        picker.hour = cfg.hour; picker.minute = cfg.minute; repeat.isChecked = cfg.repeat; strict.isChecked = cfg.strict
        findViewById<Button>(R.id.save).setOnClickListener { save() }
        findViewById<Button>(R.id.cancel).setOnClickListener {
            AlarmScheduler.cancel(this); AlarmStore.save(this, AlarmStore.load(this).copy(enabled = false)); refresh()
            Toast.makeText(this, "Alarm cancelled", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.test).setOnClickListener {
            startActivity(Intent(this, WakeActivity::class.java).putExtra("strict", strict.isChecked))
            startForegroundService(Intent(this, WakeService::class.java).putExtra("strict", strict.isChecked))
        }
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
        refresh()
    }

    private fun save() {
        val cfg = AlarmCfg(picker.hour, picker.minute, repeat.isChecked, strict.isChecked, true)
        AlarmStore.save(this, cfg)
        val t = AlarmScheduler.schedule(this, cfg)
        refresh()
        Toast.makeText(this, "Alarm set for ${DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(t))}", Toast.LENGTH_LONG).show()
        if (Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent())
            startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
    }

    private fun refresh() {
        val c = AlarmStore.load(this)
        val next = if (c.enabled) "Next alarm: " + DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
            .format(Date(AlarmScheduler.nextTime(c.hour, c.minute))) + (if (c.repeat) " (daily)" else "") + (if (c.strict) " · Strict" else "") + "\n\n"
        else "No alarm set.\n\n"
        info.text = next + "Normal mode only asks you to confirm you're up. Strict mode also requires solving a sum and removes the Stop button."
    }
}
