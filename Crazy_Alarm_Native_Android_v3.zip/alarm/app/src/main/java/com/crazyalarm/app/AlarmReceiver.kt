package com.crazyalarm.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val a = AlarmStore.load(context)
        if (a.repeat) AlarmScheduler.schedule(context, a) else AlarmStore.save(context, a.copy(enabled = false))
        context.startForegroundService(Intent(context, WakeService::class.java).putExtra("strict", a.strict))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val a = AlarmStore.load(context)
        if (a.enabled) AlarmScheduler.schedule(context, a)
    }
}
