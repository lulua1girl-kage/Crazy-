package com.crazyalarm.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

data class AlarmCfg(val hour: Int, val minute: Int, val repeat: Boolean, val strict: Boolean, val enabled: Boolean)

object AlarmStore {
    private fun p(c: Context) = c.getSharedPreferences("alarm", Context.MODE_PRIVATE)
    fun load(c: Context): AlarmCfg = p(c).let {
        AlarmCfg(it.getInt("h", 7), it.getInt("m", 0), it.getBoolean("r", false), it.getBoolean("s", false), it.getBoolean("on", false))
    }
    fun save(c: Context, a: AlarmCfg) {
        p(c).edit().putInt("h", a.hour).putInt("m", a.minute).putBoolean("r", a.repeat)
            .putBoolean("s", a.strict).putBoolean("on", a.enabled).apply()
    }
}

object AlarmScheduler {
    fun nextTime(h: Int, m: Int): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
    }.timeInMillis

    private fun fire(c: Context) = PendingIntent.getBroadcast(
        c, 42, Intent(c, AlarmReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    /** setAlarmClock is Doze-exempt and needs no exact-alarm permission. */
    fun schedule(c: Context, a: AlarmCfg): Long {
        val t = nextTime(a.hour, a.minute)
        val show = PendingIntent.getActivity(c, 43, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        c.getSystemService(AlarmManager::class.java).setAlarmClock(AlarmManager.AlarmClockInfo(t, show), fire(c))
        return t
    }

    fun cancel(c: Context) = c.getSystemService(AlarmManager::class.java).cancel(fire(c))
}
