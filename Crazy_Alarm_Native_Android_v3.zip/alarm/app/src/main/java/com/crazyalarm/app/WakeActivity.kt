package com.crazyalarm.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.WindowManager
import android.widget.*

class WakeActivity : Activity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView
    private val h = Handler(Looper.getMainLooper())
    private var strict = false
    private var solved = true
    private var answer = 0
    private var done = false
    private val yes = Regex("i'?m up|im up|i am up|out of bed|^yes$")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        setContentView(R.layout.activity_wake)
        status = findViewById(R.id.status)
        strict = intent.getBooleanExtra("strict", false)
        if (strict) {
            val x = (12..49).random(); val y = (12..49).random(); answer = x + y; solved = false
            findViewById<TextView>(R.id.question).apply { text = "$x + $y = ?"; visibility = View.VISIBLE }
            findViewById<EditText>(R.id.answer).apply {
                visibility = View.VISIBLE
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) {
                        if (s.toString().trim().toIntOrNull() == answer) { solved = true; status.text = "Correct. Now say I'm up or tap I'M UP." }
                    }
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                })
            }
            findViewById<Button>(R.id.stop).visibility = View.GONE
        }
        tts = TextToSpeech(this, this)
        findViewById<Button>(R.id.confirm).setOnClickListener { finishWake() }
        findViewById<Button>(R.id.stop).setOnClickListener { stopSession() }
    }

    override fun onInit(s: Int) {
        if (s != TextToSpeech.SUCCESS) { startListening(); return }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onError(id: String?) { if (id == "prompt") runOnUiThread { startListening() } }
            override fun onDone(id: String?) { if (id == "prompt") runOnUiThread { startListening() } }
        })
        speak("Good morning. Are you out of bed? Please say I'm up and out of bed.", "prompt")
    }

    private fun speak(x: String, id: String) { tts?.speak(x, TextToSpeech.QUEUE_FLUSH, null, id) }

    private fun startListening() {
        if (done) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
            !SpeechRecognizer.isRecognitionAvailable(this)) { status.text = "Tap I'M UP when you're up."; return }
        startService(Intent(this, WakeService::class.java).setAction(WakeService.ACTION_DUCK))
        recognizer?.destroy(); recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle) {
                val x = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase() ?: ""
                if (yes.containsMatchIn(x)) finishWake()
                else { status.text = "I didn't catch that. Please say you're up."; speak("I didn't catch that. Please say you're up.", "prompt") }
            }
            override fun onError(e: Int) { status.text = "Listening…"; h.postDelayed({ startListening() }, 1000) }
            override fun onReadyForSpeech(p: Bundle?) { status.text = "Listening… say: I'm up." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(a: Int, b: Bundle?) {}
        })
        recognizer!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
        })
    }

    private fun finishWake() {
        if (done) return
        if (strict && !solved) { status.text = "Solve the sum first."; speak("Solve the sum first.", "note"); return }
        done = true
        stopService(Intent(this, WakeService::class.java)); recognizer?.destroy(); h.removeCallbacksAndMessages(null)
        status.text = "Confirmed. You're up!"; speak("Confirmed. You're up. Have a great morning.", "bye")
        h.postDelayed({ finish() }, 2500)
    }

    private fun stopSession() {
        done = true
        stopService(Intent(this, WakeService::class.java)); recognizer?.destroy(); tts?.stop(); finish()
    }

    @Deprecated("Strict mode blocks back")
    override fun onBackPressed() { if (!strict) super.onBackPressed() }

    override fun onDestroy() {
        done = true; h.removeCallbacksAndMessages(null); recognizer?.destroy(); tts?.shutdown(); super.onDestroy()
    }
}
