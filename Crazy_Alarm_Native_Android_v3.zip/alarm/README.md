# Crazy Alarm — Native Android v3

Build: open this folder in Android Studio (Ladybug or newer, JDK 17) → let Gradle sync → Build > Build APK(s), or press Run on a phone.

v3 fixes: compile error in WakeActivity (duplicate onError); Repeat/Strict switches now work; settings persist (SharedPreferences);
alarm sound + vibration (WakeService, alarm stream, ducked while listening); daily repeat rescheduling; reschedule after reboot;
full-screen-intent wake notification (works from background); Strict mode = solve a sum + no Stop/back; runtime permission requests;
Cancel Alarm button; scheduling via setAlarmClock (Doze-exempt, no exact-alarm permission prompt).

Not verified on a device: OEM battery optimisation may still delay alarms, and Android 14+ may ask you to allow full-screen notifications.
